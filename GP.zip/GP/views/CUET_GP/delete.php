<?php
require_once("../../vendor/autoload.php");

$objProfile = new \App\Profile\Profile();
$objProfile->setData($_GET);
$oneData = $objProfile->view();


if(isset($_GET["Yes"]) && $_GET["Yes"]==1)
{
    $objProfile->delete();
    $_GET["Yes"]=0;
}


?>



<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile - Single Profile Information</title>
    <link rel="stylesheet" href="../../resource/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../resource/bootstrap/css/bootstrap-theme.min.css">
    <script src="../../resource/bootstrap/js/bootstrap.min.js"></script>


    <style>

        td{
            border: 0px;
        }

        table{
            border: 1px;
        }

        tr{
            height: 30px;
        }
    </style>



</head>
<body>


<div class="container">
    <h1 style="text-align: center" ;">Are you sure you want to delete the following record</h1>

    <table class="table table-striped table-bordered" cellspacing="0px">


        <tr>
            <th style='width: 10%; text-align: center'>ID</th>
            <th style='width: 10%; text-align: center'>Name</th>
            <th>Blood Group</th>
            <th>Contact</th>
            <th>Address</th>
        </tr>

        <?php

        echo "

                  <tr >
                
                     <td style='width: 10%; text-align: center'>$oneData->id</td>
                     <td>$oneData->name</td>
                     <td>$oneData->blood_group</td>
                     <td>$oneData->contact</td>
                     <td>$oneData->address</td>
                  </tr>
              ";

        ?>

    </table>
    <a href='delete.php?id=<?php echo $oneData->id?>&Yes=1' class="btn btn-group-lg btn-danger">Yes</a>
    <a href='blood.php' class="btn btn-group-lg btn-info">No</a>

</div>


<script src="../../resource/bootstrap/js/jquery.js"></script>

<script>
    jQuery(function($) {
        $('#message').fadeOut (550);
        $('#message').fadeIn (550);
        $('#message').fadeOut (550);
        $('#message').fadeIn (550);
        $('#message').fadeOut (550);
        $('#message').fadeIn (550);
        $('#message').fadeOut (550);
    })
</script>

</body>
</html>