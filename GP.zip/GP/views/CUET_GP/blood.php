<?php
require_once("../../vendor/autoload.php");

$objProfile = new \App\Profile\Profile();

$allData = $objProfile->index();

use App\Message\Message;

if(!isset($_SESSION)){
    session_start();
}
$msg = Message::getMessage();


echo "<div style='height: 30px'> <div  id='message'> $msg </div> </div>";


######################## pagination code block#1 of 2 start ######################################
$recordCount= count($allData);


if(isset($_REQUEST['Page']))   $page = $_REQUEST['Page'];
else if(isset($_SESSION['Page']))   $page = $_SESSION['Page'];
else   $page = 1;

$_SESSION['Page']= $page;


if(isset($_REQUEST['ItemsPerPage']))   $itemsPerPage = $_REQUEST['ItemsPerPage'];
else if(isset($_SESSION['ItemsPerPage']))   $itemsPerPage = $_SESSION['ItemsPerPage'];
else   $itemsPerPage = 3;

$_SESSION['ItemsPerPage']= $itemsPerPage;

$pages = ceil($recordCount/$itemsPerPage);
$someData = $objProfile->indexPaginator($page,$itemsPerPage);

$serial = (($page-1) * $itemsPerPage) +1;

####################### pagination code block#1 of 2 end #########################################

################## search  block 1 of 5 start ##################
if(isset($_REQUEST['search']) )$someData =  $objProfile->search($_REQUEST);


$availableKeywords=$objProfile->getAllKeywords();
$comma_separated_keywords= '"'.implode('","',$availableKeywords).'"';
################## search  block 1 of 5 end ##################

################## search  block 2 of 5 start ##################

if(isset($_REQUEST['search']) ) {
    $someData = $objProfile->search($_REQUEST);
    $serial = 1;
}
################## search  block 2 of 5 end ##################


?>



<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Green For Peace</title>
    <link rel="stylesheet" href="../../resource/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../resource/bootstrap/css/bootstrap-theme.min.css">
    <script src="../../resource/bootstrap/js/bootstrap.min.js"></script>


    <style>

        td{
            border: 0px;
        }

        table{
            border: 1px;
        }

        tr{
            height: 30px;
        }
    </style>


    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <!-- Mobile Specific Metas
    ================================================== -->
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Template CSS Files
    ================================================== -->
    <!-- Twitter Bootstrs CSS -->
    <link rel="stylesheet" href="../../resource/css/bootstrap.min.css">
    <!-- Ionicons Fonts Css -->
    <link rel="stylesheet" href="../../resource/css/ionicons.min.css">
    <!-- animate css -->
    <link rel="stylesheet" href="../../resource/css/animate.css">
    <!-- Hero area slider css-->
    <link rel="stylesheet" href="../../resource/css/slider.css">
    <!-- owl craousel css -->
    <link rel="stylesheet" href="../../resource/css/owl.carousel.css">
    <link rel="stylesheet" href="../../resource/css/owl.theme.css">
    <link rel="stylesheet" href="../../resource/css/jquery.fancybox.css">
    <!-- template main css file -->
    <link rel="stylesheet" href="../../resource/css/main.css">
    <!-- responsive css -->
    <link rel="stylesheet" href="../../resource/css/responsive.css">

    <!-- Template Javascript Files
    ================================================== -->
    <!-- modernizr js -->
    <script src="../../resource/js/vendor/modernizr-2.6.2.min.js"></script>
    <!-- jquery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <!-- owl carouserl js -->
    <script src="../../resource/js/owl.carousel.min.js"></script>
    <!-- bootstrap js -->

    <script src="../../resource/js/bootstrap.min.js"></script>
    <!-- wow js -->
    <script src="../../resource/js/wow.min.js"></script>
    <!-- slider js -->
    <script src="../../resource/js/slider.js"></script>
    <script src="../../resource/js/jquery.fancybox.js"></script>
    <!-- template main js -->
    <script src="../../resource/js/main.js"></script>


    <!-- required for search, block3 of 5 start -->

    <link rel="stylesheet" href="../../resource/bootstrap/css/jquery-ui.css">
    <script src="../../resource/bootstrap/js/jquery.js"></script>
    <script src="../../resource/bootstrap/js/jquery-ui.js"></script>

    <!-- required for search, block3 of 5 end -->



</head>
<body>

<header id="top-bar" class="navbar-fixed-top animated-header">
    <div class="container">
        <div class="navbar-header">
            <!-- responsive nav button -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- /responsive nav button -->

            <!-- logo -->
            <div class="navbar-brand">
                <a href="index.php" >
                    <img src="../../resource/images/gplogo.jpg" style="height: 100px;" alt="">
                </a>
            </div>
            <!-- /logo -->
        </div>
        <!-- main menu -->
        <nav class="collapse navbar-collapse navbar-right" role="navigation">
            <div class="main-menu">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php" >Home</a>
                    </li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="events.php">Events</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Blog & Gallery <span class="caret"></span></a>
                        <div class="dropdown-menu">
                            <ul>
                                <li><a href="blog.php">Blogs </a></li>
                                <li><a href="gallery.html">Photo Gallery</a></li>
                            </ul>
                        </div>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Blood Bank <span class="caret"></span></a>
                        <div class="dropdown-menu">
                            <ul>
                                <li><a href="blood.php">View Profiles</a></li>
                                <li><a href="create.php">Login</a></li>
                            </ul>
                        </div>
                    </li>
                    <li><a href="contact.php">Contact</a></li>

                </ul>
            </div>
        </nav>
        <!-- /main nav -->
    </div>
</header>

<!--
==================================================
    Global Page Section Start
================================================== -->
<section class="global-page-header">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="block">
                    <h2>Blood Bank</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.php">
                                <i class="ion-ios-index"></i>
                                Home
                            </a>
                        </li>
                        <li class="active">Blood Bank</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
</section>
<!--
<br>
<div class="col-xs-12 col-md-12">
    <div class="col-xs-4 col-md-4"></div>
    <div class="col-xs-4 col-md-4">
        <a href='thrashed.php?id=$oneData->id' class='btn btn-warning' style="height: 30px; width: 200px;">Requests</a>
        <a href='create.php?id=$oneData->id' class='btn btn-info' style="height: 30px; width: 200px;">Create Profile</a>
    </div>
    <div class="col-xs-4 col-md-4"></div>
</div><br> --><br><br>
<div class="col-md-12">
    <div class="col-md-4">
        <a href='create.php?id=$oneData->id' class='btn btn-info' style="height: 40px; width: 200px;">Create Profile</a>
    </div>
        <div class="col-md-8">
    <form id="searchForm" action="blood.php" method="get" style="margin-bottom: 20px; width:600px;">
        <input type="text" value="" id="searchID" name="search" placeholder="Search" width="70" class="form-control form"><br>
        <input type="checkbox"  name="byID"   checked  >By ID<br>
        <input type="checkbox"  name="byBloodGroup"  checked >By Blood Group<br><br>
        <input type="submit" class="btn btn-primary" value="search">
    </form>
        </div>
</div>

<div class="container">
    <h1 style="text-align: center">Profile - Active List</h1>

    <table class="table table-striped table-bordered" cellspacing="0px">


        <tr>
            <th style='width: 10%; text-align: center'>Serial</th>
            <th style='width: 10%; text-align: center'>ID</th>
            <th style='width: 10%; text-align: center'>Name</th>
            <th>Blood Group</th>
            <th>Contact</th>
            <th>Address</th>

            <th>Action Buttons</th>
        </tr>

        <?php
        $serial= 1;
        foreach($someData as $oneData){

            if($serial%2) $bgColor = "#cccccc";
            else $bgColor = "#ffffff";

            echo "

                  <tr  style='background-color: $bgColor'>
                     <td style='width: 10%; text-align: center'>$serial</td>
                     <td style='width: 10%; text-align: center'>$oneData->id</td>
                     <td>$oneData->name</td>
                     <td>$oneData->blood_group</td>
                     <td>$oneData->contact</td>
                     <td>$oneData->address</td>
                    

                     <td>
                     <a href='view.php?id=$oneData->id' class='btn btn-info' style='height: 40px; width: 200px;'>VIEW PROFILE</a> 
                   <!--  <a href='edit.php?id=$oneData->id' class='btn btn-primary'>EDIT</a> 
                     <a href='trash.php?id=$oneData->id' class='btn btn-warning'>SOFT DELETE</a> 
                     <a href='delete.php?id=$oneData->id' class='btn btn-danger'>DELETE</a>  -->
                     </td>
                     
                  </tr>
              ";
            $serial++;
        }
        ?>

    </table>

    <!--  ######################## pagination code block#2 of 2 start ###################################### -->
    <div align="left" class="container">

        <ul class="pagination">

            <?php

            $pageMinusOne  = $page-1;
            $pagePlusOne  = $page+1;

            if($page>$pages) Utility::redirect("index.php?Page=$pages");

            if($page>1)  echo "<li><a href='index.php?Page=$pageMinusOne'>" . "Previous" . "</a></li>";



            for($i=1;$i<=$pages;$i++)
            {
                if($i==$page) echo '<li class="active"><a href="">'. $i . '</a></li>';
                else  echo "<li><a href='?Page=$i'>". $i . '</a></li>';

            }
            if($page<$pages) echo "<li><a href='index.php?Page=$pagePlusOne'>" . "Next" . "</a></li>";
            ?>
            <select  class="form-control"  name="ItemsPerPage" id="ItemsPerPage" onchange="javascript:location.href = this.value;" >
                <?php
                if($itemsPerPage==3 ) echo '<option value="?ItemsPerPage=3" selected >Show 3 Items Per Page</option>';
                else echo '<option  value="?ItemsPerPage=3">Show 3 Items Per Page</option>';

                if($itemsPerPage==4 )  echo '<option  value="?ItemsPerPage=4" selected >Show 4 Items Per Page</option>';
                else  echo '<option  value="?ItemsPerPage=4">Show 4 Items Per Page</option>';

                if($itemsPerPage==5 )  echo '<option  value="?ItemsPerPage=5" selected >Show 5 Items Per Page</option>';
                else echo '<option  value="?ItemsPerPage=5">Show 5 Items Per Page</option>';

                if($itemsPerPage==6 )  echo '<option  value="?ItemsPerPage=6"selected >Show 6 Items Per Page</option>';
                else echo '<option  value="?ItemsPerPage=6">Show 6 Items Per Page</option>';

                if($itemsPerPage==10 )   echo '<option  value="?ItemsPerPage=10"selected >Show 10 Items Per Page</option>';
                else echo '<option  value="?ItemsPerPage=10">Show 10 Items Per Page</option>';

                if($itemsPerPage==15 )  echo '<option  value="?ItemsPerPage=15"selected >Show 15 Items Per Page</option>';
                else    echo '<option  value="?ItemsPerPage=15">Show 15 Items Per Page</option>';
                ?>
            </select>
        </ul>
    </div>
    <!--  ######################## pagination code block#2 of 2 end ###################################### -->

</div>



<script src="../../resource/bootstrap/js/jquery.js"></script>

<script>
    jQuery(function($) {
        $('#message').fadeOut (550);
        $('#message').fadeIn (550);
        $('#message').fadeOut (550);
        $('#message').fadeIn (550);
        $('#message').fadeOut (550);
        $('#message').fadeIn (550);
        $('#message').fadeOut (550);
    })
</script>

<!-- required for search, block 5 of 5 start -->
<script>

    $(function() {
        var availableTags = [

            <?php
            echo $comma_separated_keywords;
            ?>
        ];
        // Filter function to search only from the beginning of the string
        $( "#searchID" ).autocomplete({
            source: function(request, response) {

                var results = $.ui.autocomplete.filter(availableTags, request.term);

                results = $.map(availableTags, function (tag) {
                    if (tag.toUpperCase().indexOf(request.term.toUpperCase()) === 0) {
                        return tag;
                    }
                });

                response(results.slice(0, 3));

            }
        });


        $( "#searchID" ).autocomplete({
            select: function(event, ui) {
                $("#searchID").val(ui.item.label);
                $("#searchForm").submit();
            }
        });


    });

</script>
<!-- required for search, block5 of 5 end -->

<!--
==================================================
Call To Action Section Start
================================================== -->
<section id="call-to-action">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="block">
                    <h2 class="title wow fadeInDown" data-wow-delay=".3s" data-wow-duration="500ms">SO WHAT YOU THINK ?</h2>
                    <p class="wow fadeInDown" data-wow-delay=".5s" data-wow-duration="500ms">If you want to know more about us....</p>
                    <a href="emailverification.php" class="btn btn-default btn-contact wow fadeInDown" data-wow-delay=".7s" data-wow-duration="500ms">Contact With Us</a>
                </div>
            </div>

        </div>
    </div>
</section>
<!--
==================================================
Footer Section Start
================================================== -->
<footer id="footer">
    <div class="container">
        <div class="col-md-8">
            <p class="copyright">Copyright: <span>2017</span> . Design and Developed by Kibria, Arabi & Yasir</p>
        </div>
        <div class="col-md-4">
            <!-- Social Media -->
            <ul class="social">
                <li>
                    <a href="https://www.facebook.com/ads/growth/aymt/indexpage/panel/redirect/?data=%7B%22ad_account_ids%22%3A%5B538407519548669%5D%2C%22object_ids%22%3A%5B370119893078908%2C647795008596018%2C555196371222833%2C382111918565195%2C1826719607571050%2C1876284545931859%2C619792371470960%2C648814571863098%2C538385296278061%5D%2C%22campaign_ids%22%3A%5B%5D%2C%22selected_ad_account_id%22%3A538407519548669%2C%22selected_object_id%22%3A555196371222833%2C%22selected_time_range%22%3A%22%22%2C%22is_panel_collapsed%22%3A0%2C%22is_advertiser_valid%22%3A0%2C%22section%22%3A%22Object+Section%22%2C%22clicked_target%22%3A%22Selected+Object%22%2C%22event%22%3A%22click%22%7D&redirect_url=https%3A%2F%2Fwww.facebook.com%2Fcuetgp%2F%3Fref%3Daymt_indexpage_panel" class="Facebook">
                        <i class="ion-social-facebook"></i>
                    </a>
                </li>
                <li>
                    <a href="#" class="Twitter">
                        <i class="ion-social-twitter"></i>
                    </a>
                </li>
                <li>
                    <a href="#" class="Linkedin">
                        <i class="ion-social-linkedin"></i>
                    </a>
                </li>
                <li>
                    <a href="#" class="Google Plus">
                        <i class="ion-social-googleplus"></i>
                    </a>
                </li>

            </ul>
        </div>
    </div>
</footer> <!-- /#footer -->

</body>
</html>



