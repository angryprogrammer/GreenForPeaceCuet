<?php
require_once("../../vendor/autoload.php");

use App\Message\Message;

if(!isset($_SESSION)){
    session_start();
}
$msg = Message::getMessage();

echo "<div class='container' style='height: 50px'><div id='message'> $msg </div> </div> ";


$objProfile= new \App\Profile\Profile();

$objProfile->setData($_GET);
$oneData = $objProfile->view();



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile Create Form</title>


    <link rel="stylesheet" href="../../resource/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../resource/bootstrap/css/bootstrap-theme.min.css">
    <script src="../../resource/bootstrap/js/bootstrap.min.js"></script>



</head>
<body>

<div class="container">

    <div class="navbar">

        <td><a href='blood.php' class='btn btn-group-lg btn-info'>Active-List</a> </td>

    </div>



    <form  class="form-group f" action="update.php" method="post">

        Enter ID:
        <input class="form-control" type="text" name="id" value="<?php echo $oneData->id?>">
        <br>
        Enter Name:
        <input class="form-control" type="text" name="name" value="<?php echo $oneData->name?>">
        <br>
        Enter Blood Group:
        <select name="bloodGroup" class="form-control" value="<?php echo $oneData->blood_group?>">
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
        </select><br>
        <br>
        Enter Contact:
        <input class="form-control" type="text" name="contact" value="<?php echo $oneData->contact?>">
        <br>
        Enter Address:
        <select name="address" class="form-control" value="<?php echo $oneData->address?>">
            <option value="Chittagong">Chittagong</option>
            <option value="Dhaka">Dhaka</option>
        </select>
        <br>
        Donar:
        <input type="radio" id="radio" name="donar" value="Yes" required>Yes &nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" id="radio" name="donar" value="No" required>No<br><br>
        <br>

        <input type="hidden" name="id" value="<?php echo $oneData->id ?>">

        <input type="submit">

    </form>

</div>




<script src="../../resource/bootstrap/js/jquery.js"></script>

<script>
    jQuery(function($) {
        $('#message').fadeOut (550);
        $('#message').fadeIn (550);
        $('#message').fadeOut (550);
        $('#message').fadeIn (550);
        $('#message').fadeOut (550);
        $('#message').fadeIn (550);
        $('#message').fadeOut (550);
    })
</script>



</body>

</html>


