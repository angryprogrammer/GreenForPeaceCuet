<?php
require_once("../../vendor/autoload.php");

$objProfile = new \App\Profile\Profile();

$allData = $objProfile->trashed();

use App\Message\Message;

if(!isset($_SESSION)){
    session_start();
}
$msg = Message::getMessage();

echo "<div style='height: 30px'> <div  id='message'> $msg </div> </div>";

?>



<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book Title - Trashed List</title>
    <link rel="stylesheet" href="../../resource/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../resource/bootstrap/css/bootstrap-theme.min.css">
    <script src="../../resource/bootstrap/js/bootstrap.min.js"></script>


    <style>

        td{
            border: 0px;
        }

        table{
            border: 1px;
        }

        tr{
            height: 30px;
        }
    </style>



</head>
<body>

<a href='blood.php?id=$oneData->id' class='btn btn-warning'>Active List</a>
<a href='create.php?id=$oneData->id' class='btn btn-warning'>Add</a>
<div class="container">
    <h1 style="text-align: center" ;">Profile - Trashed List</h1>

    <table class="table table-striped table-bordered" cellspacing="0px">


        <tr>
            <th style='width: 10%; text-align: center'>Serial Number</th>
            <th style='width: 10%; text-align: center'>ID</th>
            <th>Name</th>
            <th>Blood Group</th>
            <th>Contact</th>
            <th>Address</th>
            <th>Action Buttons</th>
        </tr>

        <?php
        $serial= 1;
        foreach($allData as $oneData){

            if($serial%2) $bgColor = "#cccccc";
            else $bgColor = "#ffffff";

            echo "

                  <tr  style='background-color: $bgColor'>
                     <td style='width: 10%; text-align: center'>$serial</td>
                     <td style='width: 10%; text-align: center'>$oneData->id</td>
                     <td>$oneData->name</td>
                     <td>$oneData->blood_group</td>
                     <td>$oneData->contact</td>
                     <td>$oneData->address</td>

                     <td>
                     <a href='view.php?id=$oneData->id' class='btn btn-info'>View</a> 
                     
                     <a href='recover.php?id=$oneData->id' class='btn btn-warning'>Accept</a>
                     </td>
                  </tr>
              ";
            $serial++;
        }
        ?>

    </table>

</div>


<script src="../../resource/bootstrap/js/jquery.js"></script>

<script>
    jQuery(function($) {
        $('#message').fadeOut (550);
        $('#message').fadeIn (550);
        $('#message').fadeOut (550);
        $('#message').fadeIn (550);
        $('#message').fadeOut (550);
        $('#message').fadeIn (550);
        $('#message').fadeOut (550);
    })
</script>

</body>
</html>